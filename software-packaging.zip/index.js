const express = require("express");

const app = express();

app.get("/", (req, res) => {
    res.send("Software Packaging Project");
});

app.listen(3000, () => {
    console.log("Server running on port 3000");
});

require('dotenv').config();

const express = require('express');

const app = express();

const PORT = process.env.PORT;

app.get('/', (req, res) => {
  res.send('Software Packaging Project');
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
